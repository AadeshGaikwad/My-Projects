# Regression-Model-to-Predict-Cement-Compressive-Strength
This project will be based on a dataset obtained from the UCI Repository. The dataset consists of 1030 observations under 9 attributes. The attributes consist of 8 quantitative inputs and 1 quantitative output. The dataset does not contain any missing values. The dataset is focused on the compressive strength of a cement. 
